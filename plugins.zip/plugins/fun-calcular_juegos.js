let handler = async (m, { conn, command, text, usedPrefix }) => {
if (!text) throw `🤔 𝙀𝙩𝙞𝙦𝙪𝙚𝙩𝙖𝙨 𝙖𝙡 𝙥𝙚𝙧𝙨𝙤𝙣𝙖 @𝙏𝘼𝙂 𝙤 𝙚𝙨𝙘𝙧𝙞𝙗𝙖 𝙚𝙡 𝙣𝙤𝙢𝙗𝙧𝙚` 

if (command == 'gay2') {
/* let juego = `_*${text.toUpperCase()}* *ES/IS* *${(1000).getRandom()}%* *GAY*_ 🏳️‍🌈`.trim()
  
conn.sendHydrated(m.chat, juego, wm, null, md, '𝑻𝒉𝒆 𝑳𝒐𝒍𝒊𝑩𝒐𝒕-𝑴𝑫', null, null, [
['𝙈𝙚𝙣𝙪 𝙅𝙪𝙚𝙜𝙤𝙨 🎡', '#juegosmenu'],
['𝙊𝙩𝙧𝙖 𝙫𝙚𝙯 🤭', `${usedPrefix + command} ${text.toUpperCase()}`],
['𝙑𝙤𝙡𝙫𝙚𝙧 𝙖𝙡 𝙈𝙚𝙣𝙪́ ☘️', '/menu']
], m, m.mentionedJid ? {
mentions: m.mentionedJid
} : {})}
*/ 
  conn.reply(m.chat, `_*${text.toUpperCase()}* *ES 🏳️‍🌈* *${(500).getRandom()}%* *GAY*_`.trim(), m, m.mentionedJid ? { mentions: m.mentionedJid
  } : {})}

 // ------------------------------------------------------------------------------------------------------------------------------------------------
  
if (command == 'lesbiana') { 
/* let juego = `_*${text.toUpperCase()}* *ES 🏳️‍🌈* *${(500).getRandom()}%* *${command.replace('how', '').toUpperCase()}*_🏳️‍🌈`.trim()

conn.sendHydrated(m.chat, juego, wm, null, md, '𝑻𝒉𝒆 𝑳𝒐𝒍𝒊𝑩𝒐𝒕-𝑴𝑫', null, null, [
['𝙈𝙚𝙣𝙪 𝙅𝙪𝙚𝙜𝙤 🎡', '#juegosmenu'],
['𝙊𝙩𝙧𝙖 𝙫𝙚𝙯 🤭', `${usedPrefix + command} ${text.toUpperCase()}`],
['𝙑𝙤𝙡𝙫𝙚𝙧 𝙖𝙡 𝙈𝙚𝙣𝙪́ ☘️', '/menu']
], m, m.mentionedJid ? {
mentions: m.mentionedJid
} : {})}
*/  
 conn.reply(m.chat, `_*${text.toUpperCase()}* *ES 🏳️‍🌈* *${(500).getRandom()}%* *${command.replace('how', '').toUpperCase()}*_`.trim(), m, m.mentionedJid ? {
 mentions: m.mentionedJid
 } : {})} 
  
// ------------------------------------------------------------------------------------------------------------------------------------------------
  
if (command == 'pajero') {
/* let juego = `_*${text.toUpperCase()}* *ES/IS* *${(1000).getRandom()}%* *${command.replace('how', '').toUpperCase()}*_ 😏💦`.trim()
conn.sendHydrated(m.chat, juego, wm, null, md, '𝑻𝒉𝒆 𝑳𝒐𝒍𝒊𝑩𝒐𝒕-𝑴𝑫', null, null, [
['𝙈𝙚𝙣𝙪 𝙅𝙪𝙚𝙜𝙤𝙨 🎡', '#juegosmenu'],
['𝙊𝙩𝙧𝙖 𝙫𝙚𝙯 🤭', `${usedPrefix + command} ${text.toUpperCase()}`],
['𝙑𝙤𝙡𝙫𝙚𝙧 𝙖𝙡 𝙈𝙚𝙣𝙪́ ☘️', '/menu']
], m, m.mentionedJid ? {
mentions: m.mentionedJid
} : {})}
*/ 
 conn.reply(m.chat, `_*${text.toUpperCase()}* *ES 😏💦* *${(500).getRandom()}%* *${command.replace('how', '').toUpperCase()}*_`.trim(), m, m.mentionedJid ? {
 mentions: m.mentionedJid
 } : {})}
  
// ------------------------------------------------------------------------------------------------------------------------------------------------
  
if (command == 'pajera') {
/* let juego = `_*${text.toUpperCase()}* *ES/IS* *${(1000).getRandom()}%* *${command.replace('how', '').toUpperCase()}*_ 😏💦`.trim()
conn.sendHydrated(m.chat, juego, wm, null, md, '𝑻𝒉𝒆 𝑳𝒐𝒍𝒊𝑩𝒐𝒕-𝑴𝑫', null, null, [
['𝙈𝙚𝙣𝙪 𝙅𝙪𝙚𝙜𝙤𝙨 🎡', '#juegosmenu'],
['𝙊𝙩𝙧𝙖 𝙫𝙚𝙯 🤭', `${usedPrefix + command} ${text.toUpperCase()}`],
['𝙑𝙤𝙡𝙫𝙚𝙧 𝙖𝙡 𝙈𝙚𝙣𝙪́ ☘️', '/menu']
], m, m.mentionedJid ? {
mentions: m.mentionedJid
} : {})}
*/
 conn.reply(m.chat, `_*${text.toUpperCase()}* *ES 😏💦* *${(500).getRandom()}%* *${command.replace('how', '').toUpperCase()}*_`.trim(), m, m.mentionedJid ? {
 mentions: m.mentionedJid
 } : {})}
  
// ------------------------------------------------------------------------------------------------------------------------------------------------
  
if (command == 'puto') {
/* let juego = `_*${text.toUpperCase()}* *ES/IS* *${(1000).getRandom()}%* *${command.replace('how', '').toUpperCase()},* *MÁS INFORMACIÓN A SU PRIVADO 🔥🥵 XD*_`.trim()
conn.sendHydrated(m.chat, juego, wm, null, md, '𝑻𝒉𝒆 𝑳𝒐𝒍𝒊𝑩𝒐𝒕-𝑴𝑫', null, null, [
['𝙈𝙚𝙣𝙪 𝙅𝙪𝙚𝙜𝙤𝙨 🎡', '#juegosmenu'],
['𝙊𝙩𝙧𝙖 𝙫𝙚𝙯  🤭', `${usedPrefix + command} ${text.toUpperCase()}`],
['𝙑𝙤𝙡𝙫𝙚𝙧 𝙖𝙡 𝙈𝙚𝙣𝙪́ ☘️', '/menu']
], m, m.mentionedJid ? {
mentions: m.mentionedJid
} : {})}
*/  
 conn.reply(m.chat, `_*${text.toUpperCase()}* *ES* *${(500).getRandom()}%* *${command.replace('how', '').toUpperCase()},* *MÁS INFORMACIÓN A SU PRIVADO 🔥🥵 XD*_`.trim(), m, m.mentionedJid ? {
 mentions: m.mentionedJid
 } : {})}
  
// ------------------------------------------------------------------------------------------------------------------------------------------------
  
if (command == 'puta') {
/* let juego = `_*${text.toUpperCase()}* *ES/IS* *${(1000).getRandom()}%* *${command.replace('how', '').toUpperCase()},* *MÁS INFORMACIÓN A SU PRIVADO 🔥🥵 XD*_`.trim()
conn.sendHydrated(m.chat, juego, wm, null, md, '𝑻𝒉𝒆 𝑳𝒐𝒍𝒊𝑩𝒐𝒕-𝑴𝑫', null, null, [
['𝙈𝙚𝙣𝙪 𝙅𝙪𝙚𝙜𝙤𝙨 🎡', '#juegosmenu'],
['𝙊𝙩𝙧𝙖 𝙫𝙚𝙯 🤭', `${usedPrefix + command} ${text.toUpperCase()}`],
['𝙑𝙤𝙡𝙫𝙚𝙧 𝙖𝙡 𝙈𝙚𝙣𝙪́ ☘️', '/menu']
], m, m.mentionedJid ? {
mentions: m.mentionedJid
} : {})}
*/
 conn.reply(m.chat, `_*${text.toUpperCase()}* *ES* *${(500).getRandom()}%* *${command.replace('how', '').toUpperCase()},* *MÁS INFORMACIÓN A SU PRIVADO 🔥🥵 XD*_`.trim(), m, m.mentionedJid ? {
 mentions: m.mentionedJid
 } : {})} 

 // ------------------------------------------------------------------------------------------------------------------------------------------------
  
if (command == 'manco') {
/* let juego = `_*${text.toUpperCase()}* *ES/IS* *${(1000).getRandom()}%* *${command.replace('how', '').toUpperCase()} 💩*_`.trim()
conn.sendHydrated(m.chat, juego, wm, null, md, '𝑻𝒉𝒆 𝑳𝒐𝒍𝒊𝑩𝒐𝒕-𝑴𝑫', null, null, [
['𝙈𝙚𝙣𝙪 𝙅𝙪𝙚𝙜𝙤𝙨 🎡', '#juegosmenu'],
['𝙊𝙩𝙧𝙖 𝙫𝙚𝙯 🤭', `${usedPrefix + command} ${text.toUpperCase()}`],
['𝙑𝙤𝙡𝙫𝙚𝙧 𝙖𝙡 𝙈𝙚𝙣𝙪́ ☘️', '/menu']
], m, m.mentionedJid ? {
mentions: m.mentionedJid
} : {})}
*/  
 conn.reply(m.chat, `_*${text.toUpperCase()}* *ES* *${(500).getRandom()}%* *${command.replace('how', '').toUpperCase()} 💩*_`.trim(), m, m.mentionedJid ? {
 mentions: m.mentionedJid
 } : {})}
  
// ------------------------------------------------------------------------------------------------------------------------------------------------  
  
if (command == 'manca') {
/* let juego = `_*${text.toUpperCase()}* *ES* *${(1000).getRandom()}%* *${command.replace('how', '').toUpperCase()} 💩*_`.trim()
conn.sendHydrated(m.chat, juego, wm, null, md, '𝑻𝒉𝒆 𝑳𝒐𝒍𝒊𝑩𝒐𝒕-𝑴𝑫', null, null, [
['𝙈𝙚𝙣𝙪 𝙅𝙪𝙚𝙜𝙤𝙨 🎡', '#juegosmenu'],
['𝙊𝙩𝙧𝙖 𝙫𝙚𝙯 🤭', `${usedPrefix + command} ${text.toUpperCase()}`],
['𝙑𝙤𝙡𝙫𝙚𝙧 𝙖𝙡 𝙈𝙚𝙣𝙪́ ☘️', '/menu']
], m, m.mentionedJid ? {
mentions: m.mentionedJid
} : {})}
*/  
 conn.reply(m.chat, `_*${text.toUpperCase()}* *ES* *${(500).getRandom()}%* *${command.replace('how', '').toUpperCase()} 💩*_`.trim(), m, m.mentionedJid ? {
 mentions: m.mentionedJid
 } : {})}   
  
// ------------------------------------------------------------------------------------------------------------------------------------------------ 
  
if (command == 'rata') {
/* let juego = `_*${text.toUpperCase()}* *ES* *${(1000).getRandom()}%* *${command.replace('how', '').toUpperCase()} 🐁 COME QUESO 🧀*_`.trim()
conn.sendHydrated(m.chat, juego, wm, null, md, '𝑻𝒉𝒆 𝑳𝒐𝒍𝒊𝑩𝒐𝒕-𝑴𝑫', null, null, [
['𝙈𝙚𝙣𝙪 𝙅𝙪𝙚𝙜𝙤𝙨 🎡', '#juegosmenu'],
['𝙊𝙩𝙧𝙖 𝙫𝙚𝙯 🤭', `${usedPrefix + command} ${text.toUpperCase()}`],
['𝙑𝙤𝙡𝙫𝙚𝙧 𝙖𝙡 𝙈𝙚𝙣𝙪́ ☘️', '/menu']
], m, m.mentionedJid ? {
mentions: m.mentionedJid
} : {})}
*/ 
 conn.reply(m.chat, `_*${text.toUpperCase()}* *ES* *${(500).getRandom()}%* *${command.replace('how', '').toUpperCase()} 🐁 COME QUESO 🧀*_`.trim(), m, m.mentionedJid ? {
 mentions: m.mentionedJid
 } : {})}
  
// ------------------------------------------------------------------------------------------------------------------------------------------------   
  
if (command == 'prostituto') {
/* let juego = `_*${text.toUpperCase()}* *ES* *${(1000).getRandom()}%* *${command.replace('how', '').toUpperCase()} 🫦👅, QUIEN QUIERE DE SUS SERVICIOS? XD*_`.trim()
conn.sendHydrated(m.chat, juego, wm, null, md, '𝑻𝒉𝒆 𝑳𝒐𝒍𝒊𝑩𝒐𝒕-𝑴𝑫', null, null, [
['𝙈𝙚𝙣𝙪 𝙅𝙪𝙚𝙜𝙤𝙨 🎡', '#juegosmenu'],
['𝙊𝙩𝙧𝙖 𝙫𝙚𝙯 🤭', `${usedPrefix + command} ${text.toUpperCase()}`],
['𝙑𝙤𝙡𝙫𝙚𝙧 𝙖𝙡 𝙈𝙚𝙣𝙪́ ☘️', '/menu']
], m, m.mentionedJid ? {
mentions: m.mentionedJid
} : {})}
*/ 
 conn.reply(m.chat, `_*${text.toUpperCase()}* *ES* *${(500).getRandom()}%* *${command.replace('how', '').toUpperCase()} 🫦👅, QUIEN QUIERE DE SUS SERVICIOS? XD*_`.trim(), m, m.mentionedJid ? {
 mentions: m.mentionedJid
 } : {})}
  
// ------------------------------------------------------------------------------------------------------------------------------------------------   
  
if (command == 'prostituta') {
/* let juego = `_*${text.toUpperCase()}* *ES* *${(1000).getRandom()}%* *${command.replace('how', '').toUpperCase()} 🫦👅, QUIEN QUIERE DE SUS SERVICIOS? XD*_`.trim()
conn.sendHydrated(m.chat, juego, wm, null, md, '𝑻𝒉𝒆 𝑳𝒐𝒍𝒊𝑩𝒐𝒕-𝑴𝑫', null, null, [
['𝙈𝙚𝙣𝙪 𝙅𝙪𝙚𝙜𝙤𝙨 🎡', '#juegosmenu'],
['𝙊𝙩𝙧𝙖 𝙫𝙚𝙯 🤭', `${usedPrefix + command} ${text.toUpperCase()}`],
['𝙑𝙤𝙡𝙫𝙚𝙧 𝙖𝙡 𝙈𝙚𝙣𝙪́ ☘️', '/menu']
], m, m.mentionedJid ? {
mentions: m.mentionedJid
} : {})}
*/  
 conn.reply(m.chat, `_*${text.toUpperCase()}* *ES* *${(500).getRandom()}%* *${command.replace('how', '').toUpperCase()} 🫦👅, QUIEN QUIERE DE SUS SERVICIOS? XD*_`.trim(), m, m.mentionedJid ? {
 mentions: m.mentionedJid
 } : {})} 
  
 // ------------------------------------------------------------------------------------------------------------------------------------------------   
if (command == 'love') {
conn.reply(m.chat, ` *❤️❤️ MEDIDOR DE AMOR ❤️❤️* 
*El amor de ${text} por ti es de* *${Math.floor(Math.random() * 100)}%* *de un 100%*
*Deberias pedirle que sea tu  novia/o ?*`.trim(), m, m.mentionedJid ? {
 mentions: m.mentionedJid
 } : {})} 
await delay(5000)
}
handler.help = ['love', 'gay2', 'lesbiana', 'pajero', 'pajera', 'puto', 'puta', 'manco', 'manca', 'rata', 'prostituta', 'prostituto'].map(v => v + ' @tag | nombre')
handler.tags = ['calculator']
handler.command = /^love|gay2|lesbiana|pajero|pajera|puto|puta|manco|manca|rata|prostituta|prostituto/i
handler.exp = 100
export default handler
const delay = time => new Promise(res => setTimeout(res, time))