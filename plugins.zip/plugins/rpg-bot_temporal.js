let linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i
import fetch from 'node-fetch';

let handler = async (m, { conn, args, text, users, user, usedPrefix, command, isPrems, isOwner, isROwner}) => {
try {
let fkontak = { "key": { "participants":"0@s.whatsapp.net", "remoteJid": "status@broadcast", "fromMe": false, "id": "Halo" }, "message": { "contactMessage": { "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD` }}, "participant": "0@s.whatsapp.net" }

let grupos = [nna, nn, nnn, nnnt, nnntt, nnnttt]
let gata = [img5, img6, img7, img8, img9]
let enlace = { contextInfo: { externalAdReply: {title: wm + ' 🐈', body: 'support group' , sourceUrl: grupos.getRandom(), thumbnail: await(await fetch(gata.getRandom())).buffer() }}}
let enlace2 = { contextInfo: { externalAdReply: { showAdAttribution: true, mediaUrl: yt, mediaType: 'VIDEO', description: '', title: wm, body: 'The-LoliBot-MD ', thumbnailUrl: await(await fetch(img)).buffer(), sourceUrl: yt }}}
let dos = [enlace, enlace2]  

let texto0 = `${ag}𝙈𝙄 𝘾𝙍𝙀𝘼𝘿𝙊𝙍(𝘼) 𝙃𝘼 𝙍𝙀𝙎𝙏𝙍𝙄𝙉𝙂𝙄𝘿𝙊 𝙀𝙎𝙏𝘼 𝙁𝙐𝙉𝘾𝙄𝙊𝙉 𝘿𝙀 𝙄𝙉𝙂𝙍𝙀𝙎𝘼𝙍 𝙀𝙇 𝘽𝙊𝙏 𝙏𝙀𝙈𝙋𝙊𝙍𝘼𝙇𝙈𝙀𝙉𝙏𝙀 𝘼 𝙂𝙍𝙐𝙋𝙊𝙎 𝙑𝙐𝙀𝙇𝙑𝘼 𝙈𝘼𝙎 𝙏𝘼𝙍𝘿𝙀 𝙊 𝙐𝙎𝙀 𝙇𝘼 𝙁𝙐𝙉𝘾𝙄𝙊𝙉 *${usedPrefix}jadibot*`
let texto1 = `${mg}𝙐𝙎𝙀 𝙀𝙇 𝘾𝙊𝙈𝘼𝙉𝘿𝙊 𝘾𝙊𝙈𝙊 𝙀𝙎𝙏𝙀 𝙀𝙅𝙀𝙈𝙋𝙇𝙊\n*${usedPrefix + command} enlace de Grupo y Número de Token(s)*\n*${usedPrefix + command} ${grupos.getRandom()} 3*`
let texto2 = `${ag}¡𝙔𝘼 𝙉𝙊 𝙏𝙄𝙀𝙉𝙀𝙎 𝙏𝙊𝙆𝙀𝙉𝙎! 🪙\n\n𝘾𝙊𝙈𝙋𝙍𝘼 𝙏𝙊𝙆𝙀𝙉𝙎 𝙋𝘼𝙍𝘼 𝙋𝙊𝘿𝙀𝙍 𝙐𝙉𝙄𝙍 𝙇𝙊𝙇𝙄𝘽𝙊𝙏-𝙈𝘿 𝘼 𝙏𝙐 𝙂𝙍𝙐𝙋𝙊 𝘾𝙊𝙉 𝙀𝙇 𝘾𝙊𝙈𝘼𝙉𝘿𝙊:\n*${usedPrefix}buy joincount 3*`
let texto3 = `${fg}𝙀𝙉𝙇𝘼𝘾𝙀 𝙉𝙊 𝙑𝘼𝙇𝙄𝘿𝙊. 𝘿𝙀𝘽𝙀 𝙎𝙀𝙍 𝙀𝙉𝙇𝘼𝘾𝙀 𝘿𝙀 𝙂𝙍𝙐𝙋𝙊 𝘿𝙀 𝙒𝙃𝘼𝙏𝙎𝘼𝙋𝙋\n*${usedPrefix + command} ${grupos.getRandom()} 3*`
let texto4 = `${mg}𝙄𝙉𝙂𝙍𝙀𝙎𝙀 𝙀𝙇 𝙉𝙐𝙈𝙀𝙍𝙊 𝘿𝙀 𝙏𝙊𝙆𝙀𝙉(𝙎)\n*3* 𝙏𝙊𝙆𝙀𝙉 🪙 = *30* 𝙈𝙄𝙉𝙐𝙏𝙊𝙎`
let texto5 = `${fg}𝙈𝙄𝙉𝙄𝙈𝙊 *3* 𝙏𝙊𝙆𝙀𝙉(𝙎) 𝙋𝘼𝙍𝘼 𝙋𝙊𝘿𝙀𝙍 𝙐𝙉𝙄𝙍 𝘼 𝙏𝙃𝙀 𝙇𝙊𝙇𝙄𝘽𝙊𝙏-𝙈𝘿`
let texto6 = `${fg}𝙈𝘼𝙓𝙄𝙈𝙊 *3* 𝙏𝙊𝙆𝙀𝙉(𝙎) 𝙋𝘼𝙍𝘼 𝙋𝙊𝘿𝙀𝙍 𝙐𝙉𝙄𝙍 𝘼 𝙏𝙃𝙀 𝙇𝙊𝙇𝙄𝘽𝙊𝙏-𝙈𝘿`
let texto7 = `${eg}😛 𝙎𝙚 𝙝𝙖 𝙪𝙣𝙞𝙙𝙤 𝙇𝙤𝙡𝙞𝘽𝙤𝙩 𝙘𝙤𝙧𝙧𝙚𝙘𝙩𝙖𝙢𝙚𝙣𝙩𝙚 𝙖𝙡 𝙜𝙧𝙪𝙥𝙤!!`

let img1 = 'https://img.freepik.com/vector-premium/animacion-monedas-pixeles-imagenes-animacion-moneda-oro-ilustracion-vectorial_350225-3.jpg?w=2000'
let img2 ='https://img.freepik.com/premium-vector/set-8bit-pixel-graphics-icons-game-art-coins-gold-animation_534389-12.jpg?w=2000'

if (!global.db.data.settings[conn.user.jid].temporal) return await conn.reply(m.chat, texto0, fkontak, m)  
//conn.sendButton( m.chat, wm, texto0, null, [[`🙌 𝙎𝙊𝙇𝙄𝘾𝙄𝙏𝘼𝙍 𝘾𝙊𝙈𝘼𝙉𝘿𝙊`, `.reporte *Quiero unir a The-LoliBot-MD en mí Grupo. Por favor Active la función #botemporal*`], [`🍀 𝙈 𝙀 𝙉 𝙐`, `.menu`]], fkontak, m) 

if (!args[0]) return await conn.reply(m.chat, texto1, fkontak, m)  
let [_, code] = args[0].match(linkRegex) || []

if (!linkRegex.test(args[0])) return await conn.reply(m.chat, texto3, fkontak, m) 
//conn.sendButton( m.chat, wm, texto3, null, [[`🍀 𝙈 𝙀 𝙉 𝙐`, `.menu`]], fkontak, m)
let user = m.sender.split('@')[0] 

if (!(isPrems || isOwner || isROwner)) { //Para Usuarios
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let mentionedJid = [who]
let username = conn.getName(who)
//if (!args[1]) throw `${mg}*USE EL COMANDO COMO ESTE EJEMPLO*\n*${usedPrefix + command} enlace y Número de Token(s)*\n\n*EJEMPLO*\n*${usedPrefix + command} ${nn} 3*\n\n*3 TOKEN 🪙 = 30 MINUTOS*`
//if (!linkRegex.test(args[0])) throw `${fg}𝙀𝙉𝙇𝘼𝘾𝙀 𝙉𝙊 𝙑𝘼𝙇𝙄𝘿𝙊.` //Aquí 
if (user.joincount <= 1) return conn.sendButton( m.chat, wm, texto2, img1, [[`🏪 𝘾𝙊𝙈𝙋𝙍𝘼𝙍 : 𝘽𝙐𝙔 3 ${rpgshopp.emoticon('joincount')}`, `.buy joincount 3`]], fkontak, m)
if (isNaN(args[1])) return conn.sendButton( m.chat, wm, texto4, img1, [[`🍀 𝙈 𝙀 𝙉 𝙐`, `.menu`]], fkontak, m)
if (args[1] < 3) return conn.sendButton( m.chat, wm, texto5, img2, [[`🍀 𝙈 𝙀 𝙉 𝙐`, `.menu`]], fkontak, m)
if (args[1] > 3) return conn.sendButton( m.chat, wm, texto6, img2, [[`🍀 𝙈 𝙀 𝙉 𝙐`, `.menu`]], fkontak, m) //Solo ingresará si tiene 3 Token(s)
 
await delay(3 * 3000)
let res = await conn.groupAcceptInvite(code)
await conn.reply(m.chat, texto7, fkontak, m) 
//await conn.sendButton( m.chat, texto7, `${await conn.getName(res)} | ` + wm, null, [[`🍀 𝙈 𝙀 𝙉 𝙐`, `.menu`]], fkontak, m).then(async() => { 
user.joincount -= args[1] 
var jumlahHari = 600000 * args[1] // 10 minutos | Usuarios
var now = new Date() * 1
 
if (now < global.db.data.chats[res].expired) global.db.data.chats[res].expired += jumlahHari
else global.db.data.chats[res].expired = now + jumlahHari
await conn.reply(res, `✅ ${wm} 𝙎𝙚 𝙝𝙖 𝙪𝙣𝙞𝙙𝙤 𝙖𝙡 𝙜𝙧𝙪𝙥𝙤!!\n${await conn.getName(res)}\n\n*𝙍𝙚𝙘𝙪𝙚𝙧𝙙𝙚 𝙦𝙪𝙚 𝙚𝙨 ⏳𝙏𝙚𝙢𝙥𝙤𝙧𝙖𝙡, 𝙪𝙨𝙚 𝙚𝙡 𝙘𝙤𝙢𝙖𝙣𝙙𝙤 ${usedPrefix}menu 𝙋𝙖𝙧𝙖 𝙫𝙚𝙯 𝙚𝙡 𝙢𝙚𝙣𝙪*\n\n🚪 𝙈𝙚 𝙨𝙖𝙡𝙙𝙧𝙚́ 𝙖𝙪𝙩𝙤𝙢𝙖́𝙩𝙞𝙘𝙖𝙢𝙚𝙣𝙩𝙚 𝙚𝙣:\n${msToDate(global.db.data.chats[res].expired - now)}\n\n${username} 𝙇𝙚 𝙦𝙪𝙚𝙙𝙖 ${user.joincount} 𝙩𝙤𝙠𝙚𝙣𝙨(S) 🪙\n\n❕𝙋𝙪𝙚𝙙𝙚 𝙪𝙨𝙖𝙧 𝙚𝙡 𝙘𝙤𝙢𝙖𝙣𝙙𝙤 𝙩𝙖𝙢𝙗𝙞𝙚𝙣 𝙚𝙣 𝙜𝙧𝙪𝙥𝙤 𝙢𝙞𝙚𝙣𝙩𝙧𝙖𝙨 𝙚𝙨𝙩𝙚 𝙮𝙤\n\n❕𝙎𝙞 𝙦𝙪𝙞𝙚𝙧𝙚 𝙦𝙪𝙚 𝙚𝙨𝙩𝙚 𝙥𝙤𝙧 𝙢𝙖́𝙨 𝙩𝙞𝙚𝙢𝙥𝙤 𝙖𝙪𝙢𝙚𝙣𝙩𝙚 𝙚𝙡 𝙣𝙪𝙣𝙚𝙧𝙤 𝙙𝙚𝙡 𝙩𝙤𝙠𝙚𝙣𝙨 𝙘𝙪𝙖𝙣𝙙𝙤 𝙪𝙨𝙚 𝙚𝙡 𝙘𝙤𝙢𝙖𝙣𝙙𝙤\n*${usedPrefix + command}*\n\n❗𝙀𝙣 𝙘𝙖𝙨𝙤  𝙦𝙪𝙚 𝙪𝙣 𝙖𝙙𝙢𝙞𝙣 𝙢𝙚 𝙚𝙡𝙞𝙢𝙞𝙣𝙚 𝙙𝙚𝙡 𝙜𝙧𝙪𝙥𝙤 𝙮 𝙦𝙪𝙞𝙚𝙧𝙖 𝙦𝙪𝙚 𝙫𝙪𝙚𝙡𝙫𝙖,  𝙟𝙤𝙙𝙚𝙩𝙚 𝙣𝙤 𝙨𝙚 𝙫𝙖𝙣 𝙥𝙤𝙙𝙚𝙧`, fkontak, m)    
await delay(5 * 5000) 
await conn.sendMessage(res, { text: lenguajeGB.smsJoin(user), mentions: (await conn.groupMetadata(`${res}`)).participants.map(v => v.id) }, [user], { quoted: fkontak })
//for (let jid of global.owner.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').filter(v => v != conn.user.jid)) {
//let data = (await conn.onWhatsApp(jid))[0] || {}
  //if (data.exists) 
    //conn.reply(m.chat, `@${m.sender.split`@`[0]} adicional ${conn.user.name} a ${await conn.getName(res)}\njid: ${res}, el bot se apagará a tiempo: ${msToDate(global.db.data.chats[res].expired - now)}`, data.jid, m) 

} else if ((isOwner || !isPrems || isROwner)) { //Para Owner
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let mentionedJid = [who]
let username = conn.getName(who)
  
if (user.joincount === 0 ) throw `${ag}*¡YA NO TIENES TOKENS! 🪙*\n\n*COMPRA TOKENS PARA PODER INVITAR A GATABOT A TÚ GRUPO CON EL COMANDO *${usedPrefix}buy joincount 3 o ${usedPrefix}buy Para ver la Tienda*`
 if (!args[1]) throw `${mg}*USE EL COMANDO COMO ESTE EJEMPLO*\n*${usedPrefix + command} enlace y Número de Token(s)*\n\n*EJEMPLO*\n*${usedPrefix + command} ${nn} 3*\n\n*3 TOKEN 🪙 = 30 MINUTOS*`
if (!linkRegex.test(args[0])) throw `${fg}𝙀𝙉𝙇𝘼𝘾𝙀 𝙉𝙊 𝙑𝘼𝙇𝙄𝘿𝙊.` //Aquí 

await delay(3 * 3000)
let res = await conn.groupAcceptInvite(code) 
conn.reply(m.chat, `${eg}😛 𝙎𝙚 𝙝𝙖 𝙪𝙣𝙞𝙙𝙤 𝙡𝙤𝙡𝙞𝙗𝙤𝙩 𝙘𝙤𝙧𝙧𝙚𝙘𝙩𝙖𝙢𝙚𝙣𝙩𝙚 𝙖𝙡 𝙜𝙧𝙪𝙥𝙤!!`, m).then(async() => { //Si el Owner se une al Grupo no habrá temporizador
let img = 'https://i.imgur.com/8fK4h6F.jpg'
 var jumlahHari = 600000 * args[1] // 10 minutos | Owner
 var now = new Date() * 1
  if (now < global.db.data.chats[res].expired) global.db.data.chats[res].expired += jumlahHari
else global.db.data.chats[res].expired = now + jumlahHari

await conn.reply(res, `✅ ${wm} 𝙎𝙚 𝙝𝙖 𝙪𝙣𝙞𝙙𝙤 𝙖𝙡 𝙜𝙧𝙪𝙥𝙤!!\n${await conn.getName(res)}\n\n*𝙍𝙚𝙘𝙪𝙚𝙧𝙙𝙚 𝙦𝙪𝙚 𝙚𝙨 ⏳𝙏𝙚𝙢𝙥𝙤𝙧𝙖𝙡, 𝙪𝙨𝙚 𝙚𝙡 𝙘𝙤𝙢𝙖𝙣𝙙𝙤 ${usedPrefix}menu 𝙋𝙖𝙧𝙖 𝙫𝙚𝙯 𝙚𝙡 𝙢𝙚𝙣𝙪*\n\n🚪 𝙈𝙚 𝙨𝙖𝙡𝙙𝙧𝙚́ 𝙖𝙪𝙩𝙤𝙢𝙖́𝙩𝙞𝙘𝙖𝙢𝙚𝙣𝙩𝙚 𝙚𝙣:\n${msToDate(global.db.data.chats[res].expired - now)}\n\n${username} 𝙇𝙚 𝙦𝙪𝙚𝙙𝙖 ${user.joincount} 𝙩𝙤𝙠𝙚𝙣𝙨(S) 🪙\n\n❕𝙋𝙪𝙚𝙙𝙚 𝙪𝙨𝙖𝙧 𝙚𝙡 𝙘𝙤𝙢𝙖𝙣𝙙𝙤 𝙩𝙖𝙢𝙗𝙞𝙚𝙣 𝙚𝙣 𝙜𝙧𝙪𝙥𝙤 𝙢𝙞𝙚𝙣𝙩𝙧𝙖𝙨 𝙚𝙨𝙩𝙚 𝙮𝙤\n\n❕𝙎𝙞 𝙦𝙪𝙞𝙚𝙧𝙚 𝙦𝙪𝙚 𝙚𝙨𝙩𝙚 𝙥𝙤𝙧 𝙢𝙖́𝙨 𝙩𝙞𝙚𝙢𝙥𝙤 𝙖𝙪𝙢𝙚𝙣𝙩𝙚 𝙚𝙡 𝙣𝙪𝙢𝙚𝙧𝙤 𝙙𝙚𝙡 𝙩𝙤𝙠𝙚𝙣𝙨 𝙘𝙪𝙖𝙣𝙙𝙤 𝙪𝙨𝙚 𝙚𝙡 𝙘𝙤𝙢𝙖𝙣𝙙𝙤\n*${usedPrefix + command}*\n\n❗𝙀𝙣 𝙘𝙖𝙨𝙤  𝙦𝙪𝙚 𝙪𝙣 𝙖𝙙𝙢𝙞𝙣 𝙢𝙚 𝙚𝙡𝙞𝙢𝙞𝙣𝙚 𝙙𝙚𝙡 𝙜𝙧𝙪𝙥𝙤 𝙮 𝙦𝙪𝙞𝙚𝙧𝙖 𝙦𝙪𝙚 𝙫𝙪𝙚𝙡𝙫𝙖, 𝙟𝙤𝙙𝙚𝙩𝙚 𝙣𝙤 𝙨𝙚 𝙫𝙖𝙣 𝙥𝙤𝙙𝙚𝙧`, fkontak, m)  
await delay(5 * 5000)
await conn.sendMessage(res, { text: lenguajeGB.smsJoin(user), mentions: (await conn.groupMetadata(`${res}`)).participants.map(v => v.id) }, [user], { quoted: fkontak })

for (let jid of global.owner.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').filter(v => v != m.sender)) {
let data = (await conn.onWhatsApp(jid))[0] || {}
  if (data.exists) 
    conn.reply(m.chat, `@${m.sender.split`@`[0]} adicional ${conn.user.name} a ${await conn.getName(res)}\njid: ${res}, el bot se apagará a tiempo: ${msToDate(global.db.data.chats[res].expired - now)}`, data.jid, m)
                
} conn.sendButton(m.chat, '', wm, null, [['Creadora', `/creadora`], ['𝙑𝙤𝙡𝙫𝙚𝙧 𝙖𝙡 𝙈𝙚𝙣𝙪́ ☘️', '/menu']], m, res) })}
} catch (e) {
await conn.reply(m.chat, `${fg}\`\`\`POSIBLES CAUSAS
- El enlace esta incorrecto o caducado.

- No me puedo unir si previamente me han eliminado del Grupo.

- El Grupo esta Lleno, por ende no puedo unirme.
\`\`\``, m)
console.log(e)}
}
handler.help = ['temporal', 'tiempo']
handler.command = ['bottemporal', 'botemporal', 'addbot', 'botadd']
handler.register = true
export default handler
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

function msToDate(ms) {
let temp = ms
let days = Math.floor(ms / (24 * 60 * 60 * 1000));
let daysms = ms % (24 * 60 * 60 * 1000);
let hours = Math.floor((daysms) / (60 * 60 * 1000));
let hoursms = ms % (60 * 60 * 1000);
let minutes = Math.floor((hoursms) / (60 * 1000));
let minutesms = ms % (60 * 1000);
let sec = Math.floor((minutesms) / (1000));
return days + " *Día(s)* ☀️\n" + hours + " *Hora(s)* ⏳\n" + minutes + " *Minuto(s)* ⏰\n" + sec + " *Segundo(s)* 🕐\n";
}
